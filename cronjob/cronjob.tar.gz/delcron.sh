#!/bin/sh
# www.dreamwap.net

FIND=`cat /system/etc/autorun.sh | grep /online/cronjob/reboot.sh`
if [ -n "$FIND" ]; then
mount -o remount, rw /system
busybox sed -i -e '/\/online\/cronjob\/reboot.sh/d' /system/etc/autorun.sh
mount -o remount,ro /system /system
fi
rm -rf /online/cronjob
echo Uninstall finish!
reboot