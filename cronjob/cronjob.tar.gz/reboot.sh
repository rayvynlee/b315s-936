timeout='Tue, 31 Dec 2019 00:00:00 GMT'
timein=$(busybox date -d "$timeout" -D "%a, %d %b %Y %T %Z" +'%Y-%m-%d %H:%M:%S')
busybox date -s "$timein"
mkdir -p /var/spool/cron/crontabs
echo '0 */2 * * * reboot' > /var/spool/cron/crontabs/root
busybox crond
